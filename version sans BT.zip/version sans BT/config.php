<?php

define("TITRE_ADMIN", "Administration du site");

/* ---------------------------------- */
/* MESSAGES ET TEXTES PARTIE PUBLIQUE */
/* ---------------------------------- */

define("SITE_TITLE", "Calculs sur les dates");
define("SITE_SLOGAN", "Calculs en ligne sur les calendriers et les dates");
define("SITE_VERSION", "version 0.3.2");

?>